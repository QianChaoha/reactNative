var path = require('path');
module.exports={
    entry:'./build/transport/2.js',
    output:{
        path: __dirname+ '/build/out',
        filename:'out.js'
    }
}

