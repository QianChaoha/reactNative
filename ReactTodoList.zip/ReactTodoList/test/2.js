/**
 * Created by cqian on 2017/11/13.
 */
/**
 * Created by Administrator on 2017/11/13.
 */
import React from 'react';
import ReactDOM from 'react-dom';
import Foot from './1.js';


ReactDOM.render(
    <Foot />,
    document.getElementById("container")
);
