/**
 * Created by cqian on 2017/11/13.
 */
/**
 * Created by Administrator on 2017/11/13.
 */
import React from 'react';

export default class Foot extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        return <h1>Hello World</h1>;
    }
}


module.exports = {Foot};